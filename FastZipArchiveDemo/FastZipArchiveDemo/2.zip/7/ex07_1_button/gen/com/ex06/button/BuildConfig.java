/** Automatically generated file. DO NOT MODIFY */
package com.ex06.button;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}