

public final class R {
    public static final class attr {
    }
    public static final class drawable {
        public static final int icon=0x7f020000;
    }
    public static final class id {
        public static final int button1=0x7f050002;
        public static final int button2=0x7f050003;
        public static final int button3=0x7f050000;
        public static final int button4=0x7f050001;
    }
    public static final class layout {
        public static final int activity1=0x7f030000;
        public static final int activity2=0x7f030001;
        public static final int main=0x7f030002;
    }
    public static final class string {
        public static final int app_name=0x7f040001;
        public static final int hello=0x7f040000;
    }
}
